# Condominio Essentia — Potosí

Sitio web estático de Condominio Essentia.

## Publicar en GitHub Pages

1. Crea un repositorio nuevo en GitHub.
2. Sube **index.html** a la raíz del repositorio.
3. En **Settings → Pages**, selecciona:
   - **Deploy from a branch**
   - Branch: **main**
   - Folder: **/ (root)**
4. Guarda los cambios y espera la publicación de GitHub Pages.

La página está preparada como un sitio estático y las imágenes principales están integradas dentro de `index.html`, por lo que no es necesario subir una carpeta adicional de imágenes para esta versión.
